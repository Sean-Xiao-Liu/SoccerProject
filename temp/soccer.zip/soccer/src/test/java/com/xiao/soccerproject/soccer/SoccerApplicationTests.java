package com.xiao.soccerproject.soccer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoccerApplicationTests {

	@Test
	void contextLoads() {
	}

}
